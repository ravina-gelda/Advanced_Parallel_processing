# Very simple banking app

#BUILD

g++ -O3 -pthread -march=native -g -o bank ./bank.cc

#RUN

./bank

