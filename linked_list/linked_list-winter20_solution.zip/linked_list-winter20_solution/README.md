# linked_list

#BUILD
make
#RUN
./pc
