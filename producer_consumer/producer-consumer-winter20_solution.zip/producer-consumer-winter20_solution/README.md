# producer_consumer

#BUILD
make
#RUN
./pc
